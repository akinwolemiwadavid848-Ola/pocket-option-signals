/**
 * components/ui/Divider.jsx
 * ─────────────────────────────────────────────────────────────
 * Thin horizontal rule using the current theme's border color.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function Divider({ margin = "10px 0" }) {
  const { t } = useTheme();
  return <div style={{ height: 1, background: t.border, margin }} />;
}
