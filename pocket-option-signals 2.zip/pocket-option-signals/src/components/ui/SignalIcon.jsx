/**
 * components/ui/SignalIcon.jsx
 * ─────────────────────────────────────────────────────────────
 * Triangle/diamond icon representing CALL / PUT / WAIT.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";
import { getSignalColors } from "../../constants/theme.js";

const ICONS = { CALL: "▲", PUT: "▼", WAIT: "◆" };

export default function SignalIcon({ signal, size = 20 }) {
  const { t } = useTheme();
  const sc = getSignalColors(signal, t);

  return (
    <span style={{ fontSize: size, color: sc.color }}>
      {ICONS[signal] ?? "◆"}
    </span>
  );
}
