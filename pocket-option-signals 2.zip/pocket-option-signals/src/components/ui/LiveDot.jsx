/**
 * components/ui/LiveDot.jsx
 * ─────────────────────────────────────────────────────────────
 * Small pulsing dot indicating live/active status.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function LiveDot({ active = true, size = 7 }) {
  const { t } = useTheme();

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: active ? t.call : t.textMuted,
        boxShadow: active ? `0 0 6px ${t.call}` : "none",
        animation: active ? "livePulse 2s ease-in-out infinite" : "none",
      }}
    />
  );
}
