/**
 * components/ui/IndicatorRow.jsx
 * ─────────────────────────────────────────────────────────────
 * Single label/value row used in the expanded indicator table.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function IndicatorRow({ label, value, bullish, decimals = 4 }) {
  const { t } = useTheme();
  const color = bullish === true ? t.call : bullish === false ? t.put : t.textSec;

  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "3px 0" }}>
      <span style={{ fontSize: 11, color: t.textMuted, fontFamily: "var(--font-mono)" }}>{label}</span>
      <span style={{ fontSize: 11, color, fontFamily: "var(--font-mono)", fontWeight: 600 }}>
        {value !== null && value !== undefined ? Number(value).toFixed(decimals) : "—"}
      </span>
    </div>
  );
}
