/**
 * components/ui/Spinner.jsx
 * ─────────────────────────────────────────────────────────────
 * Small rotating loading indicator.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function Spinner({ size = 18, color }) {
  const { t } = useTheme();
  const c = color || t.accent;

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        border: `2px solid ${c}30`,
        borderTopColor: c,
        animation: "spin 0.8s linear infinite",
        display: "inline-block",
      }}
    />
  );
}
