/**
 * components/ui/SkeletonCard.jsx
 * ─────────────────────────────────────────────────────────────
 * Animated placeholder shown while signal data is loading.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function SkeletonCard() {
  const { t } = useTheme();
  const rows = [
    { width: "55%", height: 24, mb: 16 },
    { width: "40%", height: 14, mb: 10 },
    { width: "70%", height: 14, mb: 10 },
    { width: "30%", height: 14, mb: 10 },
    { width: "60%", height: 14, mb: 0  },
  ];

  return (
    <div
      style={{
        background: t.surface,
        border: `1px solid ${t.border}`,
        borderRadius: 16,
        padding: 20,
      }}
    >
      {rows.map((r, i) => (
        <div
          key={i}
          className="skeleton"
          style={{
            height: r.height,
            width: r.width,
            marginBottom: r.mb,
          }}
        />
      ))}
    </div>
  );
}
