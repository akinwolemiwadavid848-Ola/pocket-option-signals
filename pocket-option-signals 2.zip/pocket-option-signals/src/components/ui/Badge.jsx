/**
 * components/ui/Badge.jsx
 * ─────────────────────────────────────────────────────────────
 * Small pill-shaped label used for status, demo/live, signal type.
 * ─────────────────────────────────────────────────────────────
 */

export default function Badge({ children, color, bg, border, size = "sm" }) {
  const sizes = {
    sm: { fontSize: 10, padding: "2px 7px" },
    md: { fontSize: 11, padding: "3px 10px" },
  };

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        background: bg || color + "18",
        border: `1px solid ${border || color + "40"}`,
        color,
        borderRadius: 20,
        fontWeight: 700,
        letterSpacing: 0.8,
        fontFamily: "var(--font-mono)",
        ...sizes[size],
      }}
    >
      {children}
    </span>
  );
}
