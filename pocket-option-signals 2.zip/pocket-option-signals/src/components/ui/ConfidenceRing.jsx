/**
 * components/ui/ConfidenceRing.jsx
 * ─────────────────────────────────────────────────────────────
 * Animated SVG ring showing the confidence percentage (0–100).
 * Color reflects the active signal (CALL/PUT/WAIT).
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";
import { getSignalColors } from "../../constants/theme.js";

export default function ConfidenceRing({ value, signal, size = 72 }) {
  const { t } = useTheme();
  const sc = getSignalColors(signal, t);
  const r = size / 2 - 5;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;

  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={t.surfaceTop} strokeWidth="5" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={sc.color}
          strokeWidth="5"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.8s ease" }}
        />
      </svg>
      <div
        style={{
          position: "absolute",
          top: 0, left: 0, right: 0, bottom: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <span style={{ fontSize: 16, fontWeight: 800, color: sc.color, fontFamily: "var(--font-mono)" }}>
          {value}
        </span>
        <span style={{ fontSize: 8, color: t.textMuted, letterSpacing: 0.5 }}>%</span>
      </div>
    </div>
  );
}
