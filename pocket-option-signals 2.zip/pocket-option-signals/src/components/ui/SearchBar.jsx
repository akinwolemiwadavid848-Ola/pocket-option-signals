/**
 * components/ui/SearchBar.jsx
 * ─────────────────────────────────────────────────────────────
 * Simple text input used to filter the currency pair list.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function SearchBar({ value, onChange, placeholder = "Search pairs…" }) {
  const { t } = useTheme();

  return (
    <input
      type="text"
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        width: "100%",
        padding: "8px 12px",
        background: t.surfaceHigh,
        border: `1px solid ${t.border}`,
        borderRadius: 8,
        color: t.text,
        fontFamily: "var(--font-mono)",
        fontSize: 12,
        outline: "none",
        boxSizing: "border-box",
      }}
    />
  );
}
