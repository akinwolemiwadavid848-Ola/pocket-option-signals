/**
 * components/charts/ConfidenceDistribution.jsx
 * ─────────────────────────────────────────────────────────────
 * Horizontal bar chart showing confidence distribution buckets
 * across signal history (High / Medium / Low).
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

const BUCKETS = [
  { label: "≥80% (High)",      range: [80, 101] },
  { label: "60–79% (Medium)",  range: [60, 80]  },
  { label: "<60% (Low)",       range: [0, 60]   },
];

export default function ConfidenceDistribution({ history }) {
  const { t } = useTheme();
  if (!history || history.length === 0) return null;

  const colors = [t.call, t.wait, t.put];

  return (
    <div>
      {BUCKETS.map(({ label, range: [lo, hi] }, i) => {
        const count = history.filter((h) => h.confidence >= lo && h.confidence < hi).length;
        const pct   = (count / history.length) * 100;

        return (
          <div key={label} style={{ marginBottom: 8 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
              <span style={{ fontSize: 11, color: t.textSec, fontFamily: "var(--font-mono)" }}>{label}</span>
              <span style={{ fontSize: 11, color: colors[i], fontFamily: "var(--font-mono)" }}>
                {count} ({Math.round(pct)}%)
              </span>
            </div>
            <div style={{ height: 4, borderRadius: 2, background: t.surfaceTop }}>
              <div
                style={{
                  height: "100%",
                  width: `${pct}%`,
                  borderRadius: 2,
                  background: colors[i],
                  transition: "width 0.5s",
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
