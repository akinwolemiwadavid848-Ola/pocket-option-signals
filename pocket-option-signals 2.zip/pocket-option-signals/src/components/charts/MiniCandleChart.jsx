/**
 * components/charts/MiniCandleChart.jsx
 * ─────────────────────────────────────────────────────────────
 * Compact SVG candlestick chart used inside signal cards.
 * Renders the last 20 candles with no external charting library.
 * ─────────────────────────────────────────────────────────────
 */

import { useTheme } from "../../context/ThemeContext.jsx";

export default function MiniCandleChart({ candles, height = 60 }) {
  const { t } = useTheme();

  if (!candles || candles.length < 5) return null;

  const recent  = candles.slice(-20);
  const width   = 200;
  const values  = recent.flatMap((c) => [c.high, c.low]);
  const minV    = Math.min(...values);
  const maxV    = Math.max(...values);
  const range   = maxV - minV || 1;
  const candleW = Math.floor(width / recent.length) - 1;

  const toY = (v) => height - ((v - minV) / range) * (height - 4) - 2;

  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} style={{ opacity: 0.75 }}>
      {recent.map((c, i) => {
        const x       = i * (candleW + 1) + 1;
        const isBull  = c.close >= c.open;
        const color   = isBull ? t.call : t.put;
        const bodyTop = toY(Math.max(c.open, c.close));
        const bodyBot = toY(Math.min(c.open, c.close));
        const bodyH   = Math.max(1, bodyBot - bodyTop);

        return (
          <g key={i}>
            <line
              x1={x + candleW / 2} y1={toY(c.high)}
              x2={x + candleW / 2} y2={toY(c.low)}
              stroke={color} strokeWidth="0.5" opacity="0.6"
            />
            <rect
              x={x} y={bodyTop}
              width={candleW} height={bodyH}
              fill={color} opacity={isBull ? 0.8 : 0.9}
              rx="0.5"
            />
          </g>
        );
      })}
    </svg>
  );
}
